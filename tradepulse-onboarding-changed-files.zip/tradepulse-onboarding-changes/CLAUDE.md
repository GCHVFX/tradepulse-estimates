# TradePulse Estimates — Claude Code Context

TradePulse Estimates turns a short job description into a professional estimate in seconds. Mobile-first. Built for contractors in the field.

---

## Stack

- Next.js (App Router), TypeScript, Tailwind CSS, shadcn/ui
- Supabase (database + auth)
- Twilio (SMS), Resend (email)
- Anthropic API, `claude-haiku-4-5-20251001` for estimate generation
- Stripe (subscriptions, CA$39/month Starter, CA$69/month Pro, 14-day free trial)
- Vercel (hosting), Sentry (errors), PostHog (analytics)
- Google Places API (review link lookup in profile)

---

## Development Rules

- Server components by default, client components only when interactivity requires it
- Always output complete files, not partial snippets
- Mobile-first always
- Keep components focused. One responsibility per component.
- Prefer simple solutions over complex patterns
- No `any` — use `unknown` and narrow

---

## Scalability Principles

TradePulse should scale from early validation to thousands of subscribers without a platform rewrite.

Do not over-engineer for scale too early, but avoid choices that make scale painful later.

### Keep `plan` separate from `subscription_status`

Never use `subscription_status` for feature access.

Use:

- `plan = 'starter' | 'pro'`
- `subscription_status = 'trial' | 'active' | 'past_due' | 'cancelled' | 'complimentary'`

Feature access must use:

```ts
business.plan === "pro"
```

Subscription access (can they use the app at all) uses:

```ts
const isActive = business.subscription_status === "active";
const isTrialing = business.subscription_status === "trial" && new Date(business.trial_ends_at) > new Date();
const hasAccess = isActive || isTrialing || business.subscription_status === "complimentary";
```

---

## Folder Structure

```
app/
  new/page.tsx                   Estimate creation + streaming (client)
  estimates/page.tsx             Estimate list (server)
  estimates/[id]/page.tsx        Estimate detail (server)
  share/[id]/page.tsx            Public estimate view, no auth (server)
  payments/page.tsx              Outstanding invoices list (server, Pro-gated)
  profile/page.tsx               Business profile
  onboarding/page.tsx            First-run business setup; creates missing starter trial business row if needed
  rates/page.tsx                 Price book
  subscribe/page.tsx             Paywall / trial expired
  demo/page.tsx                  Public demo page
  go/
    electricians-postcard/page.tsx  UTM postcard redirect → /electricians
    trades-postcard/page.tsx        UTM postcard redirect → /trades
  plumbers/page.tsx              SEO landing page
  electricians/page.tsx          SEO landing page
  trades/page.tsx                SEO landing page
  plumbing-cost/page.tsx         SEO cost guide
  electrical-cost/page.tsx       SEO cost guide
  components/                    Shared UI components (see below)
  api/                           Route handlers (see below)
  auth/callback/route.ts         Supabase auth code exchange
lib/
  supabase-server.ts             supabaseAdmin, createApiClient, createSupabaseServerClient
  supabase-browser.ts            createSupabaseBrowserClient
  stripe.ts                      Single Stripe instance (import from here only)
  auth.ts                        checkUserSubscriptionAccess(userId, supabaseAdmin)
  audit-log.ts                   logEstimateChange() — writes to tpe_estimate_changes
  api-utils.ts                   validateContentType(), generateRequestId(), addRequestIdToResponse()
  rate-limit.ts                  checkRateLimit() — DB-backed, uses tpe_rate_limits table
  format-phone.ts                Canadian phone formatting
  generate-pdf.ts                jsPDF estimate rendering
  database.types.ts              Generated from live schema. Do not edit manually.
  hooks/
    use-business-profile.ts      Shared profile hook — logoUrl, businessName, businessEmail, preparedBy, isPro, googleReviewLink, isLoading
proxy.ts                         Auth + subscription middleware (NOT middleware.ts)
docs/
  SCALING-NOTES.md               Scaling assumptions and future hardening notes
```

---

## What Is Built (Current State)

### Starter Features (live)
- Estimate creation: text input → AI streaming → save to DB
- Estimate list, detail, edit, delete
- Send estimate: SMS (Twilio), email (Resend), copy link, PDF download
- Business profile: name, phone, email, logo, prepared_by
- Price book: labour rate, markup %, deposit %, common line items
- Customer details on estimates (editable after generation)
- Stripe subscription + 14-day free trial, no card required
- Billing portal (shown on profile only when subscription_status === 'active')

### Reviews Feature (live, Pro-gated)
- `mark-job-done-sheet.tsx` — bottom sheet triggered from estimate detail after marking done
- Sends Google review request via SMS using Twilio
- Custom message editable before send, Google review link appended automatically
- Tracks `review_requested_at` on `tpe_estimates`, allows resend with confirmation
- Profile has Google review link field with Google Places API lookup helper
- Gated by `business.plan === 'pro'` in `estimates/[id]/review-request/route.ts`
- "Mark Job Done" button only shown on estimate detail when `isPro === true` and status === 'sent'

### Photo Input (live, Pro-gated)
- Camera button below the job description textarea in `app/new/page.tsx` FormView
- Photo is downscaled client-side (1568px max edge, JPEG) then sent to `POST /api/analyze-photo`
- Route sends the image to `claude-sonnet-4-6` (vision), returns a plain-English job description that populates the textarea — existing Generate flow unchanged
- Photos are never stored. No DB columns involved.
- Gated by `business.plan === 'pro'` server-side; Starter sees the button greyed out with a Pro badge
- Rate limited: 5 calls per user per 60 minutes

### Payments Feature (live, Pro-gated)
- Contractor marks a done estimate as invoiced (`invoice-sheet.tsx`, amount + due date), TradePulse sends automated reminders until marked paid. No payment processing, no Stripe Connect.
- Reminder stages: pre-due (due minus 2 days), first overdue (due plus 1 day), second overdue (due plus 5 days), then ongoing weekly reminders (`overdue_ongoing`) starting at due plus 14 days until paid. One reminder per stage, tracked via `reminder_count` on `tpe_estimates` (counts above 3 are weekly reminders). Reminders stop when `payment_status = 'paid'`.
- `GET /api/cron/payment-reminders` — daily Vercel cron (17:00 UTC, `vercel.json`), secured by `Authorization: Bearer CRON_SECRET`. Sends SMS (Twilio) and email (Resend) per stage, logs each send to `tpe_payment_reminders`.
- `PATCH /api/estimates/[id]/invoice` — sets `invoice_amount`, `due_date`, `payment_status = 'unpaid'`, resets `reminder_count`
- `PATCH /api/estimates/[id]/mark-paid` — sets `payment_status = 'paid'`, `completed_at`
- Estimate detail: "Mark as Invoiced" (status done, no invoice yet) and "Mark as Paid" (unpaid invoice, inline confirm) in `estimate-actions.tsx`
- `/payments` page lists unpaid/overdue invoices, Pro-gated with upgrade prompt for Starter. Payments tab in `bottom-nav.tsx` shows a PRO badge for Starter users.
- `payment_link` field on profile (PayPal link or e-transfer email) is included in reminders; omitted cleanly when not set
- Requires `CRON_SECRET` env var

### Not Yet Built
- Follow-Up (scheduled customer outreach)
- Pro upgrade flow (no Pro subscribers yet, STRIPE_PRO_PRICE_ID not set)

---

## Routing

- `/` — public landing page (light theme)
- `/new` — estimate creation
- `/estimates` — estimate list
- `/estimates/[id]` — estimate detail
- `/share/[id]` — public estimate (no auth)
- `/payments` — outstanding invoices (Pro-gated in page, upgrade prompt for Starter)
- `/go/*` — postcard QR redirect pages (public, no auth)
- `/plumbers`, `/electricians`, `/trades` — trade-specific landing pages (public)
- `/plumbing-cost`, `/electrical-cost` — SEO cost guides (public)
- `/demo` — public demo page
- All app routes gated by `proxy.ts` (Next.js 16 proxy file, not `middleware.ts`), exported function must be named `proxy`
- `/subscribe` redirects users with access to `/estimates` (not `/new`)

Public paths are listed in `proxy.ts PUBLIC_PATHS`. Every `/api/` path is already public via the `isPublic()` function — do not add individual API routes to PUBLIC_PATHS.

---

## Database Tables (Supabase, `tpe_` prefix)

**`tpe_businesses`**
`id` (uuid PK), `owner_user_id` (FK to auth.users), `name`, `phone`, `email`, `logo_url`, `prepared_by`, `google_review_link`, `payment_link`, `plan` ('starter'|'pro', default 'starter'), `subscription_status`, `trial_ends_at`, `stripe_customer_id`, `stripe_subscription_id`, `signup_source`

**`tpe_estimates`**
`id`, `business_id` (FK to tpe_businesses.id), `title`, `summary` (full markdown content), `status` ('draft'|'sent'|'done'|'needs_review'), `source` ('app'|'website_quote'), `customer_name`, `customer_phone`, `customer_email`, `job_address`, `customer_id`, `prepared_by`, `deposit_amount`, `sent_via`, `sent_at`, `copied_at`, `completed_at`, `review_requested_at`, `created_at`
Additional columns: `payment_status`, `invoice_amount`, `due_date`, `last_reminder_sent_at`, `reminder_count` (Payments feature)

**`tpe_estimate_photos`**
`id`, `estimate_id` (FK to tpe_estimates), `storage_path`, `file_name`, `note`, `created_at` — photo metadata, files in `tpe-estimate-photos` bucket

**`tpe_pricebook_items`**
`id`, `business_id` (FK to tpe_businesses.id), `name`, `category`, `labour_price`, `material_price`, `created_at`

**`tpe_estimate_line_items`**
`id`, `estimate_id` (FK to tpe_estimates), `description`, `quantity`, `unit_price`, `line_type`, `created_at`

**`tpe_estimate_changes`**
`id`, `estimate_id` (FK to tpe_estimates), `user_id`, `change_type` ('created'|'edited'|'sent'|'deleted'), `old_value`, `new_value`, `changed_at`, `created_at` — audit log, written by `lib/audit-log.ts logEstimateChange()`

**`tpe_payment_reminders`**
`id`, `estimate_id` (FK to tpe_estimates), `business_id`, `channel`, `stage`, `message`, `sent_at`

**`tpe_rate_limits`**
`key`, `action`, `count`, `expires_at`, `created_at` — used by `lib/rate-limit.ts`

All tables: uuid primary keys, RLS enabled.

**Critical field names:**
- `tpe_businesses` uses `id` as PK and `owner_user_id` to link to auth.users
- Business name field is `name` not `company_name`
- `tpe_estimates` uses `business_id` referencing `tpe_businesses.id` (not auth.users)
- Estimate content column is `summary` not `content`
- Address field is `job_address` not `customer_address`

`lib/database.types.ts` is generated from the live schema. Do not edit manually.
To regenerate: use the Supabase MCP tool `Supabase:generate_typescript_types` (do not use CLI — it hangs on interactive auth). Filter output to `tpe_` prefixed tables only before writing to `lib/database.types.ts`.

---

## Supabase Clients

- `supabaseAdmin` — service role, bypasses RLS, server only (`@/lib/supabase-server`)
- `createSupabaseServerClient()` — SSR anon client for server components (`@/lib/supabase-server`)
- `createApiClient(request)` — request-scoped anon client for API routes (`@/lib/supabase-server`)
- `createSupabaseBrowserClient()` — browser client for client components (`@/lib/supabase-browser`)

Never import from `@supabase/auth-helpers-nextjs`. Always use `@supabase/ssr`.
Never use `.single()`. Use `.maybeSingle()`.
Never use `supabase.auth.getSession()` server-side. Always use `getUser()`.

---

## Auth Pattern

```typescript
// API routes (request-scoped)
const { supabase, applyTo } = createApiClient(request);
const { data: { user } } = await supabase.auth.getUser();
if (!user) return applyTo(NextResponse.json({ error: "Unauthorized" }, { status: 401 }));

// Server components
const supabase = await createSupabaseServerClient();
const { data: { user } } = await supabase.auth.getUser();
```

### proxy.ts (request interceptor)

proxy.ts uses its own `supabaseAdmin` (service role, created inline via `createClient`) for the business/subscription query. This bypasses RLS to avoid null-business results that caused a redirect loop when using the anon client. The anon client (with user cookies) is still used for `getUser()` to handle session token refresh.

---

## Stripe

Import only from `@/lib/stripe`. Never instantiate `new Stripe()` directly in route files.

```ts
import { stripe } from "@/lib/stripe";
```

- CA$39/month Starter plan, CA$69/month Pro plan, 14-day free trial, no card required upfront
- `trial_ends_at` + `subscription_status` (default: `'trial'`) tracked in DB
- `plan` defaults to `'starter'` at signup, set explicitly in `auth/signup/route.ts`
- Webhooks sync subscription status — `amount_paid > 0` guard in `invoice.payment_succeeded`
- Billing portal accessible from Profile page only when `subscription_status === 'active'`
- `STRIPE_PRO_PRICE_ID` env var not yet set — Pro plan not yet launched

---

## API Routes

**Estimates**
- `GET /api/estimates` — list user's estimates (id, title, status, customer_name, created_at)
- `PATCH /api/estimates` — update estimate fields (selective — only fields present in body are updated)
- `DELETE /api/estimates?id=` — delete estimate
- `POST /api/generate-estimate` — streams AI estimate, saves to `tpe_estimates`
  - Rate limited: 10 calls per user per 60 seconds via `tpe_rate_limits` table
  - Input `jobDescription` capped at 2000 characters
  - `controller.close()` must come AFTER the `__ID__` chunk is enqueued
  - Injects price book data (labour rate, markup, common items) into the prompt
- `POST /api/estimates/[id]/review-request` — sends Google review SMS via Twilio, Pro-gated
- `PATCH /api/estimates/[id]/invoice` — sets invoice amount + due date, starts payment reminders
- `PATCH /api/estimates/[id]/mark-paid` — marks invoice paid, stops reminders
- `GET /api/cron/payment-reminders` — daily reminder cron, auth via `Authorization: Bearer CRON_SECRET` (not user auth)
- `POST /api/analyze-photo` — vision analysis of a job site photo, Pro-gated
  - Accepts `{ imageBase64, mediaType }` (JPEG/PNG/WebP/GIF, base64 capped at ~6MB), returns `{ description }`
  - Uses `claude-sonnet-4-6`; image is never stored
  - Rate limited: 5 calls per user per 60 minutes via `tpe_rate_limits`

**Profile**
- `GET /api/profile` — returns `tpe_businesses` record (includes `plan`, `subscription_status`, `trial_ends_at`, `google_review_link`)
- `PATCH /api/profile` — upserts all profile fields; always send all fields to avoid overwriting with empty strings
- `POST /api/profile/find-review-link` — Google Places API search, returns ranked `{ matches, hasStrongMatch }`
- `POST /api/upload-logo` — accepts base64 `{ data, type }`, uploads to Supabase Storage `{userId}/logo`, returns `{ url }`

**Comms**
- `POST /api/send-sms` — Twilio SMS (`{ to, estimateId }`)
- `POST /api/send-email` — Resend email; do not include `reply_to` / `replyTo` (TypeScript conflict)
- `POST /api/send-reset-email` — password reset email

**Billing**
- `POST /api/billing/checkout` — creates Stripe Checkout session, redirects to Stripe
- `POST /api/billing/portal` — creates Stripe billing portal session, redirects to Stripe
- `POST /api/billing/webhook` — Stripe webhook handler (handles subscription.created/updated/deleted, invoice.payment_succeeded)

**Auth / Internal**
- `POST /api/auth/signup` — creates Supabase user + Stripe trial subscription + `tpe_businesses` row
- `GET /api/exchange-recovery` — exchanges Supabase auth code for session (password reset flow)
- `POST /api/notify-error` — emails `support@trytradepulse.com` on Anthropic API errors; always returns 200
- `POST /api/webhooks/new-signup` — Supabase auth hook → email notification on new signup; auth via `x-webhook-secret` header

---

## Shared Components

- `EstimateMarkdown` — single source of truth for estimate markdown rendering. Never duplicate. Import from `@/app/components/estimate-markdown`.
- `useBusinessProfile()` — hook returning `{ logoUrl, businessName, businessEmail, preparedBy, isPro, googleReviewLink, isLoading }`. Use in any screen that shows business identity. Never fetch `/api/profile` inside an event handler.
- `MarkJobDoneSheet` — bottom sheet for post-job review request flow. Shown after "Mark Job Done" on estimate detail. Takes `estimateId`, `googleReviewLink`, `reviewRequestedAt`, `isPro`.
- `SendEstimateSheet` — bottom sheet for SMS / email / copy link / PDF. Takes `estimateId`, `currentStatus`, customer fields, business fields.
- `EstimateActions` — fixed bottom action bar on estimate detail. Manages Send, Mark Job Done, and review request state.
- `CustomerDetailsBlock` — editable customer info block on estimate view.
- `CompanyEstimateHeader` — logo + business name header on the white estimate card.

---

## Twilio SMS

Env vars: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM_NUMBER`
Phone formatting: Canadian numbers. Strip non-digits, add +1 prefix if not present.
SMS pulls `name` from `tpe_businesses` (not `company_name`).

---

## Estimate Output Structure

Every generated estimate follows this exact structure:

1. Job Title (H1 heading — filtered from rendered output by EstimateMarkdown)
2. Job Summary (2 to 3 sentences)
3. Scope of Work (bullet list, specific tasks, plain language)
4. Line Items (labour and materials, pipe table)
5. Assumptions and Exclusions (plain bullets, no bold labels)
6. Pricing Summary (pipe table: subtotal, tax, total, deposit, balance)
7. Payment Terms (2 to 4 lines, always includes "This estimate is valid for 30 days")
8. Notes (optional, omit if nothing relevant)

Customer details are stored as columns on `tpe_estimates` and rendered via `CustomerDetailsBlock`. Not baked into AI output. H1 lines are filtered from markdown rendering. Business name and job title are displayed separately in the UI.

---

## UI Rules

- Large tap targets (minimum 44px)
- One primary action per screen, always visible
- No blank states — always show a default or example
- Progressive disclosure — advanced options hidden until needed
- Primary buttons fixed to bottom on mobile
- No dashboards as entry points
- Max 2 levels of navigation depth
- Bottom nav points to `/new`

---

## Writing Rules (applies to all UI copy and generated text)

- Write like a contractor, not like software
- Short sentences, plain language, Canadian English (labour, colour)
- No em dashes — use a period or comma instead
- No filler transitions: Additionally, Furthermore, Moreover
- No padding: It is important to note, In order to
- No forbidden words: ensure, streamline, leverage, utilize, seamless, comprehensive, facilitate
- Prices specific and labelled, never vague
- Scope descriptions specific, never vague
- UI labels: action verbs, short. Create Estimate, Send Estimate, Edit Items

---

## Claude Chat Conventions

**CC** means Claude Code. When the user says "give this to CC" or "CC prompt", they mean a prompt to paste into the Claude Code extension in VS Code.

**Claude Code prompt format:**
Plain fenced code block only — no buttons, no widgets. Example:

```
In app/components/estimate-markdown.tsx, do X.

1. Find Y and replace with Z.
2. Add this import at the top: ...
```

Never use interactive widgets or custom HTML boxes for CC prompts.
